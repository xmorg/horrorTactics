# horrorTactics
Survive your worst fears! The player faces a seamingly endless array of spooky scenarios.  It all started on that first night, when she went back to the school to get her cell phone from her locker. The classrooms where crawling with a shambling pear shaped monster.  After surviving her first "encounter", the player returned to school the next day to find everything was normal, like it never happened.  Except her friends.  Any friend who dies, seems to have never existed!  The next night ...

TODO's [code]
cut scenes
monsters get stuck on walls sometimes
attacks need to subtract action points.

set a flag where some monsters only move once spotted.  Better for "block your path senarios"
6 action points kind of drags the game in some longer levels, especially if you have already defeated opponents
  - increase action points?
  - give infinite action points until an encounter?


TODO's [art]
- smooth out player's animation
- takeshi's back animation looks bad.
- policewoman needs attack and back animations
- asylum patients need walk animations
- asylum guards need walk animations

Portraits needed
- Player (colored and face)
- Yukari (colored and face)
- Asylum patients
- Policewoman

Maps
- Tutorial can meet bullies, get papers and return to class.  Should transition to class (not tested)
- classroom can meet monsters, get cell phone and return to exit.  Does transition to appartment.
- appartment, can meet monsters, and exit (does not transition to street)
- Street, no monsters, or henchmen(not finished), tiles need to look better.
- butcher shop / map completed, monster completed, no triggers, no placement in map order
- subway (needs subway tiles!) / no monsters, no triggers, no placement in map order
- poolside Monster completed, map completed, no triggers, no placement in map order
- forrest, map completed, no monsters, no triggers, no placement in map order
- asylum, no map, no tiles or walls, monsters partially completed, folowers partially completed, no triggers, no placement in map order

Character
- [DONE]Health Points - your health, lose this and die
- [DONE]Fatigue points - fighting and running decrease fatigue points, 1 attack -2FP, 6AP used a round -1FP.
- [DONE]Mental Stability - spotting the enemy, -1, taking damage -2, witnessing death -3

 - Experience Level / Points, gain level+1 * level+1*10 to advance.
 - Points to be gained on any attack kill, objective completed, and level survived.
 - Strength, how hard you hit, Every 2 points of endurace adds 1 damage. (should also do health?
 - Speed, how fast you move. Every 2 points of speed, adds 1 action point.
 - Willpower, ability to take a hit, and keep your cool under stress. Every 2 points adds 1MSp
 - Luck, you make the best rolls! Every 3 points of Luck adds 1 to dice rolls.
 
 
